﻿namespace Assets.Scripts.Helpers.General
{
    public interface IPrintable
    {
        void Print();
    }
}
